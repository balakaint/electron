// Focus Board — Electron pilot
//
// This is a thin shell: the actual UI is the same HTML/CSS/JS that was
// already reviewed and tested as a standalone mockup. Kept nodeIntegration
// off and contextIsolation on — the renderer has no reason to touch Node
// APIs directly, and this is the setting that matters most for measuring
// a fair "real" install size / attack surface against the PySide6 build.

const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 860,
    backgroundColor: '#1B1E24',
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
