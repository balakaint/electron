# Focus Board — Electron pilot

This is the pilot for the Life OS → Electron migration. It reuses the
same UI (HTML/CSS/JS) that was already reviewed in the standalone
mockup, wrapped in a thin Electron main process — no functional changes.

## Run it

    npm install
    npm start

## Build a distributable (to measure the real number)

    npm install
    npm run dist

`electron-builder` output lands in `dist/`. That installer/package size
is the number that matters for the pilot decision — not the raw
`node_modules` size.

## Measured during this build (dev environment, for calibration only)

| | |
|---|---|
| `node_modules/electron/dist` (unpacked Electron runtime) | 260 MB |
| `node_modules` total (incl. electron-builder, dev-only) | 461 MB |

Neither of those is what ships to a user — `electron-builder` strips
dev dependencies and only bundles the Electron runtime + this app's
code. Expect the actual installer in the 120–180 MB range. **Run
`npm run dist` and record the real number before deciding on the
Habit OS / Deep Work OS migration** — that was the whole point of
doing this as a pilot instead of migrating all three apps at once.

## Security defaults

`nodeIntegration: false`, `contextIsolation: true` in `main.js`. The
renderer has no Node access. When this connects to Habit OS's data
file, add the bridge via `contextBridge.exposeInMainWorld` in
`preload.js` — don't flip `nodeIntegration` back on to shortcut it.

## Pilot exit criteria (decide before migrating Habit OS / Deep Work OS)

- [ ] Packaged installer size, measured via `npm run dist`
- [ ] Cold-start time vs the PySide6 build
- [ ] Idle memory usage vs the PySide6 build
- [ ] Whether Gumroad download/conversion numbers move after swapping
      this board in for real use
- [ ] Whether code-signing/notarization cost (mac) changes the
      no-US-entity distribution plan

## Wiring to Habit OS

Same data-layer contract as the PySide6 build: `renderer.js` currently
holds an in-memory `cards` array. Point card reads/writes at Habit OS's
existing local data file (via an IPC call through `preload.js` to
`main.js`, which does the actual file I/O) instead of touching the
array directly. No markup or CSS needs to change for that swap.
