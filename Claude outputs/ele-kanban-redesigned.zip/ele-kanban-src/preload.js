// Nothing exposed yet. When this pilot connects to Habit OS's data file,
// the IPC bridge (contextBridge.exposeInMainWorld) goes here instead of
// turning nodeIntegration back on in the renderer.
