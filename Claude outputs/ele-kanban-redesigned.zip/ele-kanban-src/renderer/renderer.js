(function(){

  // ---------- Data model ----------
  // Matches Zahid's attached spec (section 3, Data Model), with two
  // additions the spec's own business-logic section implies but the
  // example object didn't spell out: a goal needs its own nextAction/
  // outcome text (section 4, "Next Action / Outcome") and a real timer
  // needs somewhere to keep its running total (section 4 didn't
  // mention a timer at all — that's Zahid's own addition on top of the
  // spec, a real start/stop timer on whichever task is in Focus).

  let goals = [
    { id: 'g1', title: 'Talk with Pathauo', nextAction: '', outcome: '' },
  ];
  let activeGoalId = 'g1';
  let nextGoalId = 2;

  let tasks = [
    { id: 1, projectId: 'g1', title: 'Sketch onboarding flow for Life OS', description: 'Rough three-screen version, paper first.', tag: 'normal', status: 'todo', createdAt: nowIso(), updatedAt: nowIso() },
    { id: 2, projectId: 'g1', title: 'Reply to Gumroad support thread', description: '', tag: 'low', status: 'todo', createdAt: nowIso(), updatedAt: nowIso() },
    { id: 3, projectId: 'g1', title: 'Research PyInstaller code-signing for Windows', description: 'Needed before next release.', tag: 'high', status: 'todo', createdAt: nowIso(), updatedAt: nowIso() },
    { id: 4, projectId: 'g1', title: 'Write Habit OS release notes', description: 'v1.4 — five-block accordion fixes.', tag: 'high', status: 'focus', createdAt: nowIso(), updatedAt: nowIso(), elapsedMs: 0, timerRunning: false, startedAt: null },
    { id: 5, projectId: 'g1', title: 'Fix streak counter off-by-one bug', description: '', tag: 'normal', status: 'done', createdAt: nowIso(), updatedAt: nowIso() },
  ];
  let nextTaskId = 6;
  let dragId = null;
  let openMenuId = null;

  const COLS = ['todo', 'focus', 'done'];
  const STEP_LABELS = ['Goal', 'Plans', 'Actions', 'Results'];

  function nowIso(){ return new Date().toISOString(); }

  const lists = {
    todo: document.getElementById('list-todo'),
    focus: document.getElementById('list-focus'),
    done: document.getElementById('list-done'),
  };
  const counts = {
    todo: document.getElementById('count-todo'),
    focus: document.getElementById('count-focus'),
    done: document.getElementById('count-done'),
  };

  function escapeHtml(str){
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  function activeGoal(){
    return goals.find(g => g.id === activeGoalId) || goals[0];
  }

  function tasksForActiveGoal(){
    return tasks.filter(t => t.projectId === activeGoalId);
  }

  // ---------- Sidebar (goal list) ----------
  function renderSidebar(){
    document.getElementById('goalCount').textContent = goals.length;
    const listEl = document.getElementById('goalList');
    listEl.innerHTML = '';
    goals.forEach(g => {
      const btn = document.createElement('button');
      btn.className = 'goal-item' + (g.id === activeGoalId ? ' active' : '');
      btn.textContent = g.title;
      btn.addEventListener('click', () => {
        activeGoalId = g.id;
        renderAll();
      });
      listEl.appendChild(btn);
    });
  }

  // ---------- Goal header: title + progress steps ----------
  // "Update based on goal state / task completion" (spec, section 4) —
  // the spec doesn't give the exact rule, so this is a judgment call:
  // Goal (1) until any task exists, Plans (2) once tasks exist, Actions
  // (3) once something is in Focus, Results (4) once anything is
  // Closed. Reasonable default, not the one true reading of the spec —
  // worth Zahid's own sign-off if he wants a different trigger.
  function currentStep(goalTasks){
    const hasAny = goalTasks.length > 0;
    const hasFocus = goalTasks.some(t => t.status === 'focus');
    const hasClosed = goalTasks.some(t => t.status === 'done');
    if (hasClosed) return 4;
    if (hasFocus) return 3;
    if (hasAny) return 2;
    return 1;
  }

  function renderGoalHeader(goalTasks){
    const g = activeGoal();
    document.getElementById('goalTitle').textContent = g ? g.title : '—';
    document.getElementById('taskPill').textContent =
      `${goalTasks.length} task${goalTasks.length === 1 ? '' : 's'}`;

    const step = currentStep(goalTasks);
    const stepsEl = document.getElementById('progressSteps');
    stepsEl.innerHTML = '';
    STEP_LABELS.forEach((label, i) => {
      const n = i + 1;
      const state = n < step ? 'done' : (n === step ? 'current' : '');
      const stepEl = document.createElement('div');
      stepEl.className = 'progress-step' + (state ? ' ' + state : '');
      stepEl.innerHTML = `<span class="bubble">${n}</span><span class="step-label">${label}</span>`;
      stepsEl.appendChild(stepEl);
      if (n < STEP_LABELS.length){
        const conn = document.createElement('div');
        conn.className = 'progress-connector' + (n < step ? ' done' : '');
        stepsEl.appendChild(conn);
      }
    });
  }

  // ---------- Next action / Outcome ----------
  const nextActionInput = document.getElementById('nextActionInput');
  const outcomeInput = document.getElementById('outcomeInput');

  function renderNextOutcome(){
    const g = activeGoal();
    nextActionInput.value = g ? g.nextAction : '';
    outcomeInput.value = g ? g.outcome : '';
  }

  nextActionInput.addEventListener('blur', () => {
    const g = activeGoal();
    if (g) g.nextAction = nextActionInput.value.trim();
  });
  outcomeInput.addEventListener('blur', () => {
    const g = activeGoal();
    if (g) g.outcome = outcomeInput.value.trim();
  });

  // ---------- Timer (real start/stop, Focus column cards only) ----------
  function elapsedMsFor(task){
    let ms = task.elapsedMs || 0;
    if (task.timerRunning && task.startedAt) ms += Date.now() - task.startedAt;
    return ms;
  }
  function fmtElapsed(ms){
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    const pad = n => String(n).padStart(2, '0');
    return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
  }
  function toggleTimer(taskId){
    const t = tasks.find(x => x.id === taskId);
    if (!t) return;
    if (t.timerRunning){
      t.elapsedMs = elapsedMsFor(t);
      t.timerRunning = false;
      t.startedAt = null;
    } else {
      t.timerRunning = true;
      t.startedAt = Date.now();
    }
    render();
  }
  function pauseTimer(task){
    if (task.timerRunning){
      task.elapsedMs = elapsedMsFor(task);
      task.timerRunning = false;
      task.startedAt = null;
    }
  }

  // Live readout tick — only touches the DOM text, not a full render,
  // so a running timer doesn't fight typing in Next Action/Outcome or
  // reset drag state every second.
  setInterval(() => {
    tasks.forEach(t => {
      if (!t.timerRunning) return;
      const el = document.querySelector(`.timer-readout[data-timer-for="${t.id}"]`);
      if (el) el.textContent = fmtElapsed(elapsedMsFor(t));
    });
  }, 1000);

  // ---------- Board (3 columns) ----------
  function render(){
    const goalTasks = tasksForActiveGoal();
    renderGoalHeader(goalTasks);

    COLS.forEach(col => {
      const listEl = lists[col];
      listEl.innerHTML = '';
      const colTasks = goalTasks.filter(t => t.status === col);
      counts[col].textContent = colTasks.length;

      if (colTasks.length === 0){
        const hint = document.createElement('div');
        hint.className = 'empty-hint';
        const glyph = col === 'focus' ? '●' : (col === 'done' ? '✓' : '▤');
        const line1 = col === 'todo' ? 'Nothing queued.'
          : col === 'focus' ? 'Nothing in focus.'
          : 'Nothing closed yet.';
        const line2 = col === 'todo' ? 'Add a task to get started.'
          : col === 'focus' ? 'Pull one thing in from Queued.'
          : 'Completed tasks will appear here.';
        hint.innerHTML = `<span class="glyph">${glyph}</span><span class="line1">${line1}</span><span class="line2">${line2}</span>`;
        listEl.appendChild(hint);
        return;
      }

      colTasks.forEach(t => {
        const card = document.createElement('div');
        card.className = 'card';
        card.draggable = true;
        card.dataset.id = t.id;
        card.dataset.priority = t.tag;

        const idx = COLS.indexOf(col);
        const canLeft = idx > 0;
        const canRight = idx < COLS.length - 1;

        let timerHtml = '';
        if (col === 'focus'){
          const running = !!t.timerRunning;
          timerHtml = `
            <div class="card-timer ${running ? 'running' : ''}">
              <button class="timer-toggle ${running ? 'running' : ''}" data-timer-toggle="${t.id}" aria-label="${running ? 'Pause timer' : 'Start timer'}">${running ? '⏸' : '▶'}</button>
              <span class="timer-readout" data-timer-for="${t.id}">${fmtElapsed(elapsedMsFor(t))}</span>
            </div>`;
        }

        card.innerHTML = `
          <div class="card-top">
            <h4>${escapeHtml(t.title)}</h4>
          </div>
          ${t.description ? `<p class="note">${escapeHtml(t.description)}</p>` : ''}
          <div class="card-foot">
            <span class="tag" data-tag="${t.tag}">${t.tag.toUpperCase()}</span>
            <div class="card-controls">
              <button class="ctrl-btn" data-move="left" data-id="${t.id}" ${canLeft ? '' : 'disabled'} aria-label="Move left">◀</button>
              <button class="ctrl-btn" data-move="right" data-id="${t.id}" ${canRight ? '' : 'disabled'} aria-label="Move right">▶</button>
              <div class="card-menu-wrap">
                <button class="ctrl-btn" data-menu="${t.id}" aria-label="More">⋮</button>
                <div class="card-menu ${openMenuId === t.id ? 'open' : ''}" data-menu-panel="${t.id}">
                  <button data-delete="${t.id}">Delete</button>
                </div>
              </div>
            </div>
          </div>
          ${timerHtml}
        `;

        card.addEventListener('dragstart', () => {
          dragId = t.id;
          requestAnimationFrame(() => card.classList.add('dragging'));
        });
        card.addEventListener('dragend', () => {
          card.classList.remove('dragging');
          dragId = null;
        });

        listEl.appendChild(card);
      });
    });

    renderNextOutcome();
  }

  function renderAll(){
    renderSidebar();
    render();
  }

  // Moving a task out of Focus auto-pauses its timer — a card sitting
  // in Queued or Closed with a silently running clock would be a
  // real accuracy bug, not a cosmetic one, now that the timer is real.
  function setStatus(task, status){
    if (task.status === 'focus' && status !== 'focus') pauseTimer(task);
    task.status = status;
    task.updatedAt = nowIso();
  }

  // drag over / drop per column
  Object.keys(lists).forEach(col => {
    const listEl = lists[col];
    listEl.addEventListener('dragover', e => {
      e.preventDefault();
      listEl.classList.add('drag-over');
    });
    listEl.addEventListener('dragleave', () => {
      listEl.classList.remove('drag-over');
    });
    listEl.addEventListener('drop', e => {
      e.preventDefault();
      listEl.classList.remove('drag-over');
      if (dragId == null) return;
      const t = tasks.find(x => x.id === dragId);
      if (t) setStatus(t, col);
      render();
    });
  });

  // Card controls: move arrows, kebab menu, delete (event delegation)
  document.getElementById('board').addEventListener('click', e => {
    const moveBtn = e.target.closest('[data-move]');
    if (moveBtn && !moveBtn.disabled){
      const id = Number(moveBtn.dataset.id);
      const dir = moveBtn.dataset.move;
      const t = tasks.find(x => x.id === id);
      if (t){
        const idx = COLS.indexOf(t.status);
        const nextIdx = dir === 'left' ? idx - 1 : idx + 1;
        if (nextIdx >= 0 && nextIdx < COLS.length) setStatus(t, COLS[nextIdx]);
      }
      render();
      return;
    }

    const menuBtn = e.target.closest('[data-menu]');
    if (menuBtn){
      const id = Number(menuBtn.dataset.menu);
      openMenuId = openMenuId === id ? null : id;
      render();
      return;
    }

    const delBtn = e.target.closest('[data-delete]');
    if (delBtn){
      const id = Number(delBtn.dataset.delete);
      tasks = tasks.filter(x => x.id !== id);
      openMenuId = null;
      render();
      return;
    }

    const timerBtn = e.target.closest('[data-timer-toggle]');
    if (timerBtn){
      toggleTimer(Number(timerBtn.dataset.timerToggle));
      return;
    }

    // Click outside any menu closes it.
    if (openMenuId !== null && !e.target.closest('.card-menu-wrap')){
      openMenuId = null;
      render();
    }
  });

  // composer open/close/save — scoped to the active goal via projectId
  document.querySelectorAll('[data-add]').forEach(btn => {
    btn.addEventListener('click', () => {
      const col = btn.dataset.add;
      const composer = document.querySelector(`[data-composer="${col}"]`);
      composer.classList.add('open');
      composer.querySelector('[data-field="title"]').focus();
    });
  });

  document.querySelectorAll('[data-cancel]').forEach(btn => {
    btn.addEventListener('click', () => {
      const composer = btn.closest('.composer');
      composer.classList.remove('open');
      composer.querySelectorAll('input').forEach(i => i.value = '');
    });
  });

  document.querySelectorAll('[data-save]').forEach(btn => {
    btn.addEventListener('click', () => {
      const col = btn.dataset.save;
      const composer = document.querySelector(`[data-composer="${col}"]`);
      const title = composer.querySelector('[data-field="title"]').value.trim();
      const note = composer.querySelector('[data-field="note"]').value.trim();
      if (!title) return;
      tasks.push({
        id: nextTaskId++,
        projectId: activeGoalId,
        title,
        description: note,
        tag: 'normal',
        status: col,
        createdAt: nowIso(),
        updatedAt: nowIso(),
      });
      composer.classList.remove('open');
      composer.querySelectorAll('input').forEach(i => i.value = '');
      render();
    });
  });

  // New goal (sidebar composer)
  const newGoalInput = document.getElementById('newGoalInput');
  const newGoalBtn = document.getElementById('newGoalBtn');
  function addGoal(){
    const title = newGoalInput.value.trim();
    if (!title) return;
    const id = 'g' + (nextGoalId++);
    goals.push({ id, title, nextAction: '', outcome: '' });
    activeGoalId = id;
    newGoalInput.value = '';
    renderAll();
  }
  newGoalBtn.addEventListener('click', addGoal);
  newGoalInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') addGoal();
  });

  // ---------- Sales pulse: milestone ladder + required run-rate ----------
  // Unchanged from the pre-redesign build — kept per Zahid's own call,
  // since the attached spec doesn't include this section at all.
  const RUNGS = [100, 1000, 10000, 100000, 1000000];
  const unitsInput = document.getElementById('unitsSold');
  const dateInput = document.getElementById('targetDate');
  const rungFill = document.getElementById('rungFill');
  const rungMarks = document.getElementById('rungMarks');
  const rungNote = document.getElementById('rungNote');
  const runRateNote = document.getElementById('runRateNote');

  function fmt(n){ return n.toLocaleString('en-US'); }

  function nextRung(units){
    for (const r of RUNGS){ if (units < r) return r; }
    return RUNGS[RUNGS.length - 1];
  }
  function prevRung(units){
    let p = 0;
    for (const r of RUNGS){ if (units >= r) p = r; else break; }
    return p;
  }

  function renderPulse(){
    const units = Math.max(0, Number(unitsInput.value) || 0);
    const lo = prevRung(units);
    const hi = nextRung(units);
    const span = hi - lo || 1;
    const pct = Math.min(100, ((units - lo) / span) * 100);
    rungFill.style.width = pct.toFixed(1) + '%';

    rungMarks.innerHTML = RUNGS.map(r => {
      const reached = units >= r;
      return `<span class="${reached ? 'reached' : ''}">${r >= 1000000 ? '1M' : (r >= 1000 ? (r / 1000) + 'K' : r)}</span>`;
    }).join('');

    if (units >= 1000000){
      rungNote.textContent = 'Ladder cleared. Redefine the next target.';
    } else {
      rungNote.textContent = `${fmt(hi - units)} units to the ${hi >= 1000000 ? '1M' : (hi / 1000) + 'K'} rung.`;
    }

    if (dateInput.value){
      const target = new Date(dateInput.value + 'T00:00:00');
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const daysLeft = Math.ceil((target - today) / 86400000);
      const remaining = Math.max(0, 1000000 - units);

      if (daysLeft <= 0){
        runRateNote.textContent = remaining === 0 ? 'Target reached.' : 'Target date has passed.';
      } else {
        const perDay = remaining / daysLeft;
        runRateNote.textContent = `Needs ${fmt(Math.ceil(perDay))} units/day for ${daysLeft} days.`;
      }
    } else {
      runRateNote.textContent = 'Set a date to see the required daily rate.';
    }
  }

  unitsInput.addEventListener('input', renderPulse);
  dateInput.addEventListener('input', renderPulse);
  renderPulse();

  renderAll();
})();
